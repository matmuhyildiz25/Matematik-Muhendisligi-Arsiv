#include<stdio.h>

main() {
	char A[100], ch;
	int i, counter=0;
	
	printf("A: ");
	gets(A);
	
	printf("ch: ");
	scanf("%c", &ch);
	
	for(i=0; A[i]!='\0';i++){
		if(A[i]==ch)
			counter++;
	}
	
	printf("The number of %c in %s is %d\n", ch, A, counter);	
}


