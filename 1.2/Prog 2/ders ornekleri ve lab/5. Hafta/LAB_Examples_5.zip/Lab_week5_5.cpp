#include<stdio.h>
#include<string.h>

void reverse(char *A, int n)
{
	int i, j, r, len_A;
	char temp[100];
	
	
	len_A = strlen(A); 
	
	if(len_A<n)
		r = len_A;
	else
		r = n;	
	
	for(i= r-1, j=0; i>=0 ;i--, j++){
		temp[j] = A[i]; 
		
	}
	
	for(i=n; i<len_A; i++)	
		temp[i] = A[i];		
	
	temp[len_A] = '\0';
	strcpy(A,temp);
}


main() {
	char A[100];
	
	printf("A: ");
	gets(A);
	
	reverse(A, 10);
	puts(A);
						
}


