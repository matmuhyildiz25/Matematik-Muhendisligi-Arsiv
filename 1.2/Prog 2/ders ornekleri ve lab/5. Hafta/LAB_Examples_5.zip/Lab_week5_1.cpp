#include<stdio.h>
#include<stdlib.h>
#define N 3

main() {
	int i, j;
	int *P[N];
	
	for(i=0;i<N;i++)
	{
		P[i] = (int *) malloc(sizeof(int)*2*(i+1));
		if(P[i]==NULL){
			printf("Memory Error!\n");
			exit(1);
		}
	}
	for(i=0;i<N;i++)
	{
		for(j=0; j<2*(i+1); j++){
			//P[i][j] = i*j;
			*(P[i]+j) = i + j;	
			printf("%3d", P[i][j]);
		}
		printf("\n");	
	}
	
	for(i=0;i<N;i++)
	{
		for(j=0; j<2*(i+1); j++)
            printf("%d ", P[i]+j);
	    printf("\n");
	}
}


