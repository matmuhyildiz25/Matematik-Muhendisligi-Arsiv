#include<stdio.h>

main() {
	char A[100], ch;
	int i, vowels = 0, consonants = 0, numerics = 0;
		
	printf("A: ");
	gets(A);
	
	for(i=0; A[i]!='\0'; i++){
		if(A[i]=='a' || A[i]=='e' || A[i]=='i' || A[i]=='o' || A[i]=='u' || 
		   A[i]=='A' || A[i]=='E' || A[i]=='I' || A[i]=='O' || A[i]=='U')
		   	  vowels++;
		else if((A[i]>='a' && A[i]<='z') || (A[i]>='A' && A[i]<='Z'))  
			consonants++;
		else if	(A[i]>='0' && A[i]<='9')
			numerics++;
	}
	
	printf("The number of vowels is %d\n", vowels);	
	printf("The number of consonants is %d\n", consonants);
	printf("The number of numerics is %d\n", numerics);
}


