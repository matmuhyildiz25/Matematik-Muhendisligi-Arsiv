#include<stdio.h>

int Find_Letter(char *A, char ch)
{
	int i, counter=0;
		
	for(i=0; A[i]!='\0';i++){
		if(A[i]==ch)
			counter++;
	}
	
	return counter;
	
}
main() {
	char A[100], ch;
	
	
	printf("A: ");
	gets(A);
	
	printf("ch: ");
	scanf("%c", &ch);
	

	printf("The number of %c in %s is %d\n", ch, A, Find_Letter(A, ch));	
}


